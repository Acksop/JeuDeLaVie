import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;


/**
* This Applet is a simple exercise based on the game of the life (from
* Conway).
*/


public class Life extends Applet implements ActionListener{

	LifeSimulator simulator;
	Button clear = new Button("effacer");
	Button random = new Button("hazard");
	Button zoomin = new Button("+");
	Button zoomout = new Button("-");
	Button process = new Button("1 cycle");
	Button start = new Button("demarrer");
	Button stop = new Button("arreter");
	
    public void init(){
        super.init();
		
		simulator = new LifeSimulator();
        simulator.requestFocus();
        
        setLayout(new BorderLayout());
        add(simulator, BorderLayout.CENTER);
        
    	Panel controls = new Panel();
    	clear.addActionListener(this);
    	controls.add(clear);
    	random.addActionListener(this);
    	controls.add(random);
    	zoomin.addActionListener(this);
		controls.add(zoomin);
    	zoomout.addActionListener(this);
    	controls.add(zoomout);
    	process.addActionListener(this);
    	controls.add(process);
    	start.addActionListener(this);
    	controls.add(start);
    	stop.addActionListener(this);
    	controls.add(stop);
    	
    	add(controls, BorderLayout.SOUTH);

        simulator.random();
        simulator.repaint();
        //simulator.start();

    }

    public void actionPerformed(ActionEvent evt){
        

        if(evt.getSource()==process){
        	simulator.perform();
        	simulator.repaint();
        	return;
       	}

        if(evt.getSource()==clear){
        	simulator.clear();
        	simulator.repaint();
       	}

        if(evt.getSource()==random){
        	simulator.random();
        	simulator.repaint();
       	}

		if(evt.getSource()==start){
			simulator.start();
		}

		if(evt.getSource()==stop){
			simulator.stop();
		}

    }

}



class LifeSimulator extends Panel 
	implements KeyListener, MouseListener, MouseMotionListener, Runnable{

    /**
    * The board who contains the values of each cell. If the value is 0 or
    * 2 there is nothing on the cell. If there is 1 or 3, there is a cell.
    */
    private int[][] tab;
    private int nb_cols=64;
    private int nb_rows=64;
    private int zoom=4;

	Thread thread;
	boolean paused=true;
	
	public LifeSimulator(){

        tab=new int[nb_rows][nb_cols];
        for(int row=0; row<nb_rows; row++)
            for(int col=0; col<nb_cols; col++)
                tab[row][col]=0;
		zoom = 4;
		setSize(nb_rows*zoom, nb_cols*zoom);
		
        addMouseListener(this);
        addMouseMotionListener(this);
        addKeyListener(this);
        
	}
	

    public void perform(){
        int row, col;
        int nb_vois;

        for(row=0; row<nb_rows; row++)
            for(col=0; col<nb_cols; col++){
                nb_vois=0;
                if(tab[(row+nb_rows-1)%nb_rows][(col+nb_cols-1)%nb_cols]%2 ==1)
                    nb_vois++;
                if(tab[(row+nb_rows-1)%nb_rows][(col)%nb_cols]%2 ==1)
                    nb_vois++;
                if(tab[(row+nb_rows-1)%nb_rows][(col+1)%nb_cols]%2 ==1)
                    nb_vois++;
                if(tab[(row)%nb_rows][(col+nb_cols-1)%nb_cols]%2 ==1)
                    nb_vois++;
                if(tab[(row)%nb_rows][(col+1)%nb_cols]%2 ==1)
                    nb_vois++;
                if(tab[(row+1)%nb_rows][(col+nb_cols-1)%nb_cols]%2 ==1)
                    nb_vois++;
                if(tab[(row+1)%nb_rows][(col)%nb_cols]%2 ==1)
                    nb_vois++;
                if(tab[(row+1)%nb_rows][(col+1)%nb_cols]%2 ==1)
                    nb_vois++;

                if(tab[row][col]%2 == 1)
                    if(nb_vois<2 || nb_vois>3)
                        tab[row][col]+=0;  /* cell die */
                    else
                        tab[row][col]+=2;  /* cell survive */
                else
                    if(nb_vois==3)
                        tab[row][col]+=2;  /* cell is born */
                    else
                        tab[row][col]+=0;  /* still nothing */
            }

        for(row=0; row<nb_rows; row++)
            for(col=0; col<nb_cols; col++)
                tab[row][col]/=2;
    }


	public void clear(){
        for(int row=0; row<nb_rows; row++)
            for(int col=0; col<nb_cols; col++)
                tab[row][col]=0;
    }
    
    
    public void random(){
    	//random = new Random();
    	
        for(int row=0; row<nb_rows; row++)
            for(int col=0; col<nb_cols; col++)
                tab[row][col]= (Math.random()>.5) ? 1 : 0;
	}	



	// Start & stop methods
	public void stop() {
		paused = true;
	}	

	public void start() { 
		paused = false;
		if (thread==null) {
			thread = new Thread(this); 
			thread.setPriority(Thread.MIN_PRIORITY); 
			thread.start(); 
		}
		
	}
	
	public synchronized void run(){
	
		long sleepTime = 0;
		long startTime = 0;
		
		while (Thread.currentThread()==thread) {

			startTime = System.currentTimeMillis();

			if(!paused){
    			perform();
    			repaint();
    			
    			// Compute sleeping time for next loop
    			sleepTime = startTime + 100 - System.currentTimeMillis();
    			//System.out.println("sleep " + sleepTime + " ms");
    			
    			if (sleepTime > 0) {
    				try { Thread.sleep(sleepTime); }
    				catch (InterruptedException e) { }
    			}
			}
		}
	}
	

    public void keyPressed(KeyEvent evt){
        perform();
        repaint();
    }
    public void keyReleased(KeyEvent evt){}
    public void keyTyped(KeyEvent evt){}


    public void mousePressed(MouseEvent evt){
        int row, col;
        Graphics g;

        col = evt.getX()/zoom;
        row = evt.getY()/zoom;

        if(col>=nb_cols || row>=nb_rows)
            return;

        tab[row][col]=1-tab[row][col];

        g=getGraphics();
        if(tab[row][col]==1)
            g.setColor(Color.black);
        else
            g.setColor(Color.white);
        g.fillRect(col*zoom, row*zoom, zoom, zoom);
            
    }
    public void mouseReleased(MouseEvent evt){}
    public void mouseClicked(MouseEvent evt){}
    public void mouseEntered(MouseEvent evt){}
    public void mouseExited(MouseEvent evt){}

	public void mouseMoved(MouseEvent evt){}
	public void mouseDragged(MouseEvent evt){

        int row, col;
        Graphics g;

        col = evt.getX()/zoom;
        row = evt.getY()/zoom;

        if(col>=nb_cols || row>=nb_rows)
            return;

        tab[row][col]=1;

        g=getGraphics();
        if(tab[row][col]==1)
            g.setColor(Color.black);
        else
            g.setColor(Color.white);
        g.fillRect(col*zoom, row*zoom, zoom, zoom);    	
	}
	
	
	/** surchargee pour eviter le clignotement lors de l'affichage. */
    public void repaint(){
        paint(getGraphics());
    }

    public void paint(Graphics g){
        int row, col;

        for(row=0; row<nb_rows; row++)
            for(col=0; col<nb_cols; col++)
                if(tab[row][col]==1 || tab[row][col]==3){
                    g.setColor(Color.black);
                    g.fillRect(col*zoom, row*zoom, zoom, zoom);    
                }
                else {
                    g.setColor(Color.white);
                    g.fillRect(col*zoom, row*zoom, zoom, zoom);
                }
    }

}

